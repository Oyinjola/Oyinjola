""" 
Author: Oyinkansola Jolaogun
Date: Monday June 14
Description: this program is an entertainment trivia game with three different levels of difficulty and 10 questions for each level. """
print("Hello 👋 , and welcome to Entertainment trivia")
print("\n")
print("The general rules of the game are as follows:")
print("\n")
print("1. Answer the questions that show up on the screen and if you get the question right,you get a point but if you get it wrong,you earn no points.")
print("\n")
print("For example; If these options are displayed on the screen\na.Hi\nb.Hello\nc.Bye\nDo not input a,b or c, input Hi, Hello or Bye")
print("\n")
print("Make sure to keep watch of capital letters\nFor example, if you are given the choices\na.Yes\nb.No\nDo not input yes or no,it will be marked wrong\nInstead,input Yes or No")
print("\n")
print("2.You have three difficulties to choose from; easy, medium and\nhard")
print("\n")
print("Please use correct spelling and use capital letters for first and last names")
print("\n")
print("Input an answer only from the options listed to you")
print("\n")
print("GOOD LUCK 👍")
score=0#This is the point system for the easy level
points=0#This is the point system for the medium level
mark=0#This is the point system for the hard level
while True:
  difficulty=(input("What level of difficulty would you like;\na. Easy\nb. Medium\nc. Hard\nInput answer here:"))
  if difficulty == ("Easy"):
    print("Okay we will begin")
    print("\n")
    question_1=input("1. Who is the female celebrity with the most grammy wins?\na. Alison Krauss\nb. Rihanna\nc. Beyonce\nInput answer here:")
    #answer is Alison Krauss
    if question_1 == ("Alison Krauss"):
      print("correct✔️\nTime for question number two")
      score=score+1
      #the score is to keep a tally of their points so it can be displayed at the end of the game
      print("\n")
    else:
      print("WRONG ANSWER❌\nYou can do better on the next question\n")
      print("The right answer was Alison Krauss")
      print("\n")
    question_2=input("2. Which female celebrity played the role of Cat Valentine on Nickelodeon?\na.Demi Lovato\nb.Ariana Grande\nc.Selena Gomez\nInput answer here:")
    #answer is Ariana Grande
    if question_2 == ("Ariana Grande"):
      print("Yay, you got it right\nMoving on to quesion number three")
      score=score+1
      print("\n")
    else:
      print("WRONG ANSWER❌\nThe correct option was Ariana Grande\nBetter luck next time")
      print("\n")
    question_3=input("3.Who won the oscar aat the 93rd Academy Awards for best actress?\na.Frances McDormand\nb.Chloe Zhao\nc.Youn Yuh Jung\nInput answer here:")
    #The answer is Frances McDormand
    if question_3 == ("Frances McDormand"):
      print("Correct✔️\nFrances won this award for her role as Fern in the film Nomadland")
      score=score+1
      print("\n")
    else:
      print("WRONG ANSWER❌\nThe right answer would be Frances McDormand")
      print("\n")
    question_4=input("4.Which of the following is not a group but a soloist?\na.Exid\nb.Dean\nc.BTS\nInput answer here:")
    #The answer is Dean
    if question_4 == ("Dean"):
      print("you got it right🎉\nDean is a solo Khiphop artist")
      score=score+1
      print("\n")
    else:
      print("OOPS, The correct answer was Dean")
      print("\n")
    question_5=input("5. Who played the role of spiderman in the avengers endgame?\na.Chris Hemsworth\nb.Chris Pratt\nc.Tom Holland\nInput answer here:")
    #The answer is Tom Holland
    if question_5 == ("Tom Holland"):
      print("Correct✔️\n Tom Indeed played the the role of spiderman in this movie")
      score=score+1
      print("\n")
    else:
      print("WRONG ANSWER❌\nSpiderman was played by Tom Holland")
      print("\n")
    question_6=input("6.Who sang the hit single;drivers license?\na.Sabrina Carpenter\nb.Leonardo DiCarprio\nc.Olivia Rodrigo\nInput answer here:")
    #The answer is Olivia Rodrigo
    if question_6 == ("Olivia Rodrigo"):
      print("Yes🎉, Olivia is the 18 year old genius behind this masterpiece")
      score=score+1
      print("\n")
    else:
      print("Yikes❌,wrong answer.\nThe correct choice would be Olivia Rodrigo")
      print("\n")
    question_7=input("7.Who sang starboy?\na.The Weeknd\nb.Giveon\nc.Childish Gambino\nInput answer here:")
    #Answer is The Weeknd
    if question_7 == ("The Weeknd"):
      print("You were spot on with this one")
      score=score+1
      print("\n")
    else:
      print("OOPS, wrong ANSWER❌")
      print("The correct answer is The Weeknd")
      print("\n")
    question_8=input("8.What are Japanese cartoons/animations called?\na.Manwha\nb.Anime\nc.Manga\nInput answer here:")
    #The answer is anime
    if question_8 == ("Anime"):
      print("Wow, you got it right🎊")
      score=score+1
      print("\n")
    else:
      print("❌,the correct option is actually Anime. Some popular ones include; Naruto, Attack on Titan and Dragon ball z")
      print("\n")
    question_9=input("9.Which of the following is not a model?\na.Sora Choi\nb.Naomi Campbell\nc.Kim Jennie\nInput answer here:")
    #The answer for this question is Kim Jennie
    if question_9 == ("Kim Jennie"):
      print("You got this right🎉,Jennie is a singer not a model")
      score=score+1
      print("/n")
    else:
      print("WRONG ❌, The correct answer would be Kim Jennie")
      print("\n")
    question_10=input("10.And for the last question; Which netflix show had the biggest ever debut garnering over 82 million viewers in its first month after release?\na.The Queen's Gambit\nb.Bridgerton\nc.The Crown\nd.Stranger Things\nInput answer here:")
    #The answer is bridgerton
    if question_10 == ("Bridgerton"):
      print("Correct ✔️,Bridgerton holds this title with it's incredible actors and actresses as well as it's beautifully romantic plot")
      score=score+1
      print("/n")
    else:
      print("UH OH, the correct answer is bridgerton")
      print("\n")
    print("Thank you so much for playing, your total score is",score)
  elif difficulty == ("Medium"):
    print("Okay we will begin")
    print("\n")
    #from here on out, instead of using question and then underscore to signify the question number, I will use the difficulty level instead. For example, instead of question_1 for the first question, I will use medium_1.
    medium_1=input("1.Which of the following celebrities does not have a famous parent?\na.Nicki Minaj\nb.Bella Hadid\nc.Doja Cat\nInput answer here:")
    #The answer is Nicki Minaj
    if medium_1 == ("Nicki Minaj"):
      print("✔️, you got it right, Nicki Minaj does not have a famous parent")
      points=points+1
      print("\n")
    else:
      print("❌The correct answer is Nicki Minaj")
      print("\n")
    medium_2=input("2. Which of the following is not a celebriy sibling duo?\na.Chloe and Halle\nb.Gigi and Bella\nc.Tom and David\nInput answer here:")
    #The answer is Tom and David
    if medium_2 == ("Tom and David"):
      print("Yes🎉, you got it right")
      points=points+1
      print("\n")
    else:
      print("Wrong answer❌,the correct option would be Tom and David")
      print("\n")
    medium_3=input("3.Kate hudson is the daughter of which famous actor/actress?\na.Goldie Hawn\nb.Kurt Russell\nc.Gus Trikonis\nInput answer here:")
    #answer is Goldie Hawn
    if medium_3 == ("Goldie Hawn"):
      print("✔️,you were spot on")
      points=points+1
      print("\n")
    else:
      print("OOPS❌, the right option is Goldie Hawn")
      print("\n")
    medium_4=input("4.Which of the following is not a record\entertainment label?\na.Interscope Records\nb.Yg Entertainment\nc.Rivid entertainment\nInput answer here:")
    #the answer is livid enertainment
    if medium_4 == ("Rivid Entertainment"):
      print("Correct✔️,Rivid Entertainment is not a real thing")
      points=points+1
      print("\n")
    else:
      print("Sorry, the correct answer is Rivid Entertainment, Better luck next time")
      print("\n")
    medium_5=input("5.How many seasons does the hit medical show;Grey's Anatomy have?\na.Five\nb.Ten\nc.Seventeen\nInput answer here:")
    if medium_5 == ("Seventeen"):
      print("correct✔️, Grey's Anatomy has seventeen long seasons")
      points=points+1
      print("\n")
    else:
      print("You got it wrong❌,the corect answer is seventeen seasons ")
      print("\n")
    medium_6=input("6.Which of the following artists have not won a grammy?\na.Billie Eilish\nb.Ariana Grande\nc.Nicki Minaj\nInpu answer here:")
    if medium_6 == ("Nicki Minaj"):
      print("Yes🎉, you picked the right one")
      points=points+1
      print("\n")
    else:
      print("UH OH❌, the answer is Nicki Minaj")
      print("\n")
    medium_7=input("7.Which of the following is not a british royal?\na.Kate Middleton\nb.Michael D'addario\nc.Prince Charles\nInput answer here:")
    if medium_7 == ("Michl D'addario"):
      print("WOW 🎉, you got it right, as royal as he may seem, Michael D'addario is unforunately not a member of the British Royal family ")
      points=points+1
      print("\n")
    else:
      print("❌ Unfortunately, Michael D'addario is the correct answer")
      print("\n")
    medium_8=input("8.Which of the following was sung by Adele?\na.Hello\nb.Ophelia\nc.Jenny\nInput answer here:")
    if medium_8 == ("Hello"):
      print("Correct✔️,Hello was sung by Adele")
      points=points+1
      print("\n")
    else:
      print("Wrong answer❌,the correct answer is Hello")
      print("\n")
    medium_9=input("9.Which name in this list is not biologically related to the rest?\na.Kendall Jenner\nb.Stormi Webster\nc.Scott Disick\nInput answer here:")
    if medium_9 == ("Scott Disick"):
      print("Correct🎉,Scott Disick is the right answer")
      points=points+1
      print("\n")
    else:
      print("Wrong answer❌,the correct answer is Scott Disick")
      print("\n")
    medium_10=input("10.Which of the following tiktokers have said the n word?\na.Lilhuddy\nb.Cynthia Parker\nc.Zoe Laverne\nd.All\nInput answer here:")
    if medium_10 == ("All"):
      print("As sad as it is,all is the correct option")
      points=points+1
      print("\n")
    else:
      print("Wrong answer❌,the correct answer is All")
      print("\n")
    print("Thank you for playing the medium level of the entertainment trivia game. Your score is;",points)
  elif difficulty == ("Hard"):
    print("\n")
    print("wow, you must have a lot of confidence in your knowledge to be able to play the hard version😏\n")
    print("Let's put that knowledge to the test.")
    #from here on out i will use the variable;"hard" alongside a number the signify a question
    hard_1=input("1.Who was named People magazine's Sexiest Man Alive in 1991?\na.Patrick Swayze\nb.Leonardio Dicaprio\nc.Steven Seagal\nInput answer here:")
    #The answer is Patrick Swayze
    if hard_1 == ("Patrick Swayze"):
      print("Correct✔️,you picked the right option")
      mark=mark+1
      print("\n")
    else:
      print("WRONG ANSWER❌ the correct choice was Patrick Swayze")
      print("\n")
    hard_2=input("How old was Princess Diana when she got married\na.25\nb.20\nc.18\nInput answer here:")
    #The answer is 20
    if hard_2 == ("20"):
      print("Correct✔️, Princess Diana got married at the young age of 20")
      mark=mark+1
      print("\n")
    else:
      print("WRONG ANSWER❌The princess got married at age 20")
      print("\n")
    hard_3=input("How many children does Donakd Trump have?\na.5\nb.3\nc.4\nInput answer here:")
    #The answer is 5
    if hard_3 == ("5"):
      print("Correct🎉,Donald Trump has five children")
      mark=mark+1
      print("\n")
    else:
      print("WRONG ANSWER❌ the correct option is 5")
      print("\n")
    hard_4=input("Which of the following is not a Jpop group?\na.AKB48\nb.Baby Metal\nc.Purple Kiss\nInput answer here:")
    #The answer is purple kiss
    if hard_4 == ("Purple Kiss"):
      print("Yes🎉,Purple Kiss is a kpop group not a Jpop group")
      mark=mark+1
      print("\n")
    else:
      print("Yikes❌ Purple Kiss is the right answer")
      print("\n")
    hard_5=input("What sport did Tom Cruise play before he go injured?\na.Fencing\nb.Wrestling\nc.Soccer\nInput answer here:")
    #The answer is Wrestling
    if hard_5 == ("Wrestling"):
      print("Correct🎉,he originally wanted to be a professional wrestler")
      mark=mark+1
      print("\n")
    else:
      print("OOPS❌,the right answer is Wrestling")
      print("\n")
    hard_6=input("Which of the following is the odd one out?\na.Chadwick Boseman\nb.Martin Freeman\nc.Paul Rudd\nInput answer here:")
    #The answer is print
    if hard_6 == ("Paul Rudd"):
      print("correct✔️,he is the odd one out because he was not in Black Panther")
      mark=mark+1
      print("\n")
    else:
      print("Uh Oh, the odd one out is Paul Rudd since he did not star in Black Panther")
      print("\n")
    hard_7=input("7.Which of the following is not a director?\na.Vin Diesel\nb.Anthony Russo\nc.David Lynch\nInput answer here:")
    #The answer is Vin Diesel
    if hard_7 == ("Vin Diesel"):
      print("Correct✔️,Vin Diesel is not a director, he is an actor and filmaker")
      mark=mark+1
      print("\n")
    else:
      print("❌,the correct answer is Vin Diesel")
      print("\n")
    hard_8=input("8.Who was crowned the most handsome man in 2020 by TC chandler?\na.Kim Taehyung\nb.Pewdiepie\nc.Jeon Jungkook\nInput answer here:")
    #The answer is pewdiepie
    if hard_8 == ("Pewdiepie"):
      print("You got it right🎊")
      mark=mark+1
      print("\n")
    else:
      print("WRONG ANSWER❌,the correct option is Pewdiepie")
      print("\n")
    hard_9=input("9.What is the highest grossing movie of all time?\na.Avengers Endgame\nb.Avatar\nc.Titanic\nInput answer here:")
    #answer is Avatar
    if hard_9 == ("Avatar"):
      print("You got it right,It has a gross of 42,847,246,203")
      mark=mark+1
      print("\n")
    else:
      print("Yikes❌, the correct answer is Avatar with a lifetime gross of 42,847,246,203")
      print("\n")
    hard_10=input("10.How many houses did Marilyn Monroe live in throughout the course of her life?\na.5\nb.8\nc.43\nInput answer here:")
    #answer is 43
    if hard_10 == ("43"):
      print("Correct🎉,she lived in 43 different homes")
      mark=mark+1
      print("\n")
    else:
      print("WRONG ANSWER❌,she lived in 43 different homes")
      print("43")
    print("Your total score is;",mark)
  else:
    print("invalid choice")
  Yes=True
  replay=input("would you like to play again:\na.Yes\nb.No\nInput answer here\n")
  if replay == ("No"):
    break
  elif replay == ("Yes"):
    True
  else:
    print("invalid entry")

